package com.bdt.kafka;

public class AppConfig {
    final static String applicationID = "SingleProducer";
    final static String bootstrapServers = "localhost:9092";
    final static String topicName = "invoice";
    final static int numEvents = 500000;
}
