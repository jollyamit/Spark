package com.bdt.kafka;

public class AppConfig {
    final static String applicationID = "Multi-Threaded-Producer";
    final static String topicName = "multi-thread-topic";
    final static String kafkaConfigFileLocation = "kafka.properties";
    final static String[] eventFiles = {"../../datasets/stockdata-1.csv","../../datasets/stockdata-2.csv"};
}
