package com.bdt.kafka;

public class AppConfig {
    final static String applicationID = "Transactions";
    final static String bootstrapServers = "localhost:9092";
    final static String topicName1 = "trx-1-topic";
    final static String topicName2 = "trx-2-topic";
    final static int numEvents = 2;
    final static String transaction_id = "Trx-Producer";
}
