package com.bdt.kafka;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Properties;

public class TransactionProducer {
    private static final Logger logger = LogManager.getLogger();

    public static void main(String[] args) {

        System.out.println("Creating Kafka Producer...");
        Properties props = new Properties();
        props.put(ProducerConfig.CLIENT_ID_CONFIG, AppConfig.applicationID);
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, AppConfig.bootstrapServers);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, AppConfig.transaction_id);

        KafkaProducer<Integer, String> producer = new KafkaProducer<>(props);
        producer.initTransactions();

        System.out.println("Starting First Transaction...");
        producer.beginTransaction();
        try {
            for (int i = 1; i <= AppConfig.numEvents; i++) {
                producer.send(new ProducerRecord<>(AppConfig.topicName1, i, "Simple Message-T1-" + i));
                producer.send(new ProducerRecord<>(AppConfig.topicName2, i, "Simple Message-T1-" + i));
            }
            System.out.println("Committing First Transaction.");
            producer.commitTransaction();
        }catch (Exception e){
            System.out.println("ERROR: Exception in First Transaction. Aborting...");
            producer.abortTransaction();
            producer.close();
            throw new RuntimeException(e);
        }

        System.out.println("Starting Second Transaction...");
        producer.beginTransaction();
        try {
            for (int i = 1; i <= AppConfig.numEvents; i++) {
                producer.send(new ProducerRecord<>(AppConfig.topicName1, i, "Simple Message-T2-" + i));
                producer.send(new ProducerRecord<>(AppConfig.topicName2, i, "Simple Message-T2-" + i));
            }
            System.out.println("ERROR: Aborting Second Transaction.");
            producer.abortTransaction();
        }catch (Exception e){
            System.out.println("ERROR: Exception in Second Transaction. Aborting...");
            producer.abortTransaction();
            producer.close();
            throw new RuntimeException(e);
        }

        System.out.println("Finished - Closing Kafka Producer.");
        producer.close();

    }
}
