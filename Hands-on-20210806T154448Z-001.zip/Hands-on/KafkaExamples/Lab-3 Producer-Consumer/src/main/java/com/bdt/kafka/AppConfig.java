package com.bdt.kafka;

public class AppConfig {
    final static String applicationID = "ProducerConsumer";
    final static String bootstrapServers = "localhost:9092";
    final static String topicName = "producer-consumer-topic";
    final static int numEvents = 1000000;
}
