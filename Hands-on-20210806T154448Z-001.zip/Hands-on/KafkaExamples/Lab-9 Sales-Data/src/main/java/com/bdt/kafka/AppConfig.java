package com.bdt.kafka;

public class AppConfig {
    final static String applicationID = "State-Sales-Data";
    final static String topicName = "sales-data";
    final static String kafkaConfigFileLocation = "kafka.properties";
    final static String[] eventFiles = {"datasets/sales1.csv","datasets/sales2.csv"};
}
