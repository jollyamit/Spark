package com.bdt.kafka;

public class AppConfig {
    public final static String applicationID = "PosSimulator";
    public final static String bootstrapServers = "localhost:9092,localhost:9093";
}
